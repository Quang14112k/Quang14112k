online shopping system with both admin and user layouts.

admin login details  Email=admin@gmail.com and Password=123456789.
# phpProject
